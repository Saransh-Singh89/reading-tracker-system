{
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
